/*
Willkommen! Zum neunten Aufgabenblatt vom Programmierkurs gibt es leider keine Übungsaufgaben.
*/
